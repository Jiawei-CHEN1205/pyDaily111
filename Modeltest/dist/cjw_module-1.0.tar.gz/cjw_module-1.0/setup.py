from distutils.core import setup 
# name 模块名称 
# version 版本号 
# description 描述 
# author 作者 
# py_modules 要发布的内容 
setup(name="cjw_module", version="1.0", description="生日快乐祝福", 
author="Wendy-CHEN", py_modules=['Modeltest']) 
